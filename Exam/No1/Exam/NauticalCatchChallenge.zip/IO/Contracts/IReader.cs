﻿namespace NauticalCatchChallenge.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
